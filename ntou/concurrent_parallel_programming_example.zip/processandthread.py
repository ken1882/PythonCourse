# -*- coding: utf-8 -*-
"""
Created on Sat Oct 14 16:36:36 2017

@author: Admin
"""

import os
import time
import threading
import multiprocessing
import math

def wait():
    print("PID:{} Process name:{} Thread name:{}".format(os.getpid(),
          multiprocessing.current_process().name,
          threading.current_thread().name))
    time.sleep(1) # sleep one second

def computing():
    print("PID:{} Process name:{} Thread name:{}".format(os.getpid(),
          multiprocessing.current_process().name,
          threading.current_thread().name))
    x = 0
    y = 0.001
    while x < 10000000:
        y = math.cos(y)
        x = x + 1
        
    return y

if __name__=="__main__":
    total_cpu = os.cpu_count()
    
    for func in [wait, computing]:
        print("{} test {} {}".format('-'*10,func.__name__,'-'*10))
        start_time = time.time()
        for _ in range(total_cpu):
            func()
        end_time = time.time()
        print("serial execution: {}".format(end_time-start_time))
        
        
        start_time = time.time()
        threads = [threading.Thread(target=func) for _ in range(total_cpu)]
        for thread in threads:
            thread.start()
    
        for thread in threads:
            thread.join()
        end_time = time.time()
        print("execution time of multithreading: {}".format(end_time-start_time))
        del threads
        
        start_time = time.time()
        processes = [multiprocessing.Process(target=func) for _ in range(total_cpu)]
        for process in processes:
            process.start()
        for process in processes:
            process.join()
        end_time = time.time()
        print("execution time of multiprocessing: {}".format(end_time-start_time))
        del processes
    
    
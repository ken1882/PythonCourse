# -*- coding: utf-8 -*-
"""
Created on Sun Dec 24 18:04:49 2017

@author: Admin
"""

import threading
import time

def timer_func(n):
    t = threading.Timer(n, timer_func,(n,))
    t.start()
    for _ in range(5): 
        print('{},hello'.format(threading.current_thread().name))
    print('{} leaves timer_func'.format(threading.current_thread().name))
     
t = threading.Timer(2,timer_func,(2,))
t.start()
for _ in range(20)  :
    print('The main thread is doing something')
    time.sleep(10)

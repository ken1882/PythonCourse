# -*- coding: utf-8 -*-
"""
Created on Sun Dec 24 18:45:57 2017

@author: Admin
"""

import time
import concurrent.futures
def echo(x):
    if x == 0:
        time.sleep(10)
    else:
        time.sleep(1)
    return x    

begin = time.time()
data = [x for x in range(100)]
with concurrent.futures.ThreadPoolExecutor(max_workers = 100) as executor:
     #result   = list(executor.map(echo,data)) # store the results in a list
     for i in executor.map(echo,data): # iterate over the result
        print(i)

print(time.time()-begin)

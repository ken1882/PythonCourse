# -*- coding: utf-8 -*-
"""
Created on Sun Dec 24 18:42:45 2017

@author: Admin
"""
import time
import concurrent.futures
def echo(x):
    if x == 0:
        time.sleep(10)
    else:
        time.sleep(1)
    return x    

begin = time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers = 10) as executor:
    fs = [ executor.submit(echo,x)  for x in range(100)]
    for future in concurrent.futures.as_completed(fs):
        print(future.result())
print(time.time()-begin)

# -*- coding: utf-8 -*-
"""
Created on Sun Dec 24 17:58:35 2017

@author: Admin
"""

import threading
import time

def timer_func(n):
    for _ in range(n):
        print('{},hello'.format(threading.current_thread().name))

t = threading.Timer(5, timer_func, (10,))   
t.start()
time.sleep(10)

# -*- coding: utf-8 -*-
"""
Created on Sun Dec 10 10:16:04 2017

@author: Admin
"""

import threading
import time
def func1():
    global t2
    time.sleep(1)
    print('{} waits for {}\n'.format(threading.current_thread().name,t2.name))
    t2.join()
    print('{} completes\n'.format(threading.current_thread().name))
    
def func2():
    global t1
    time.sleep(1)
    print('{} waits for {}\n'.format(threading.current_thread().name,t1.name))
    t1.join()
    print('{} completes\n'.format(threading.current_thread().name))

#t1 = threading.Thread(target=func1)
#t2 = threading.Thread(target=func2)
#
#t1.start()
#t2.start()
import threading
import time

def timer_func(n):
    t = threading.Timer(n, timer_func,(n,))
    t.start()
    for _ in range(5): 
        print('{},hello'.format(threading.current_thread().name))
    print('{} leaves timer_func'.format(threading.current_thread().name))
     
t = threading.Timer(2,timer_func,(2,))
t.start()
for _ in range(100)  :
    print('The main thread is doing something')
    time.sleep(10)





# -*- coding: utf-8 -*-
"""
Created on Sat Dec  9 20:40:40 2017

@author: Admin
"""

import concurrent.futures
import os
import time
def count_number_of_files(path):
	file_count = 0
	total_size = 0
	for root,dirs,files in os.walk(path):
		file_count = file_count + len(files)
		for f in files:
			try:
				total_size = total_size + os.path.getsize(os.path.join(root,f))
			except PermissionError:
				pass
	return (file_count,total_size)

def executor_map(path):
    
    begin = time.time()
    total_files = 0
    total_size  = 0
    subdir = []
    for entry in os.scandir(path):
        if entry.is_file():
            total_files = total_files + 1
            total_size  = total_size + os.path.getsize(os.path.join(path,entry.name))
        elif entry.is_dir():
            subdir.append(os.path.join(path,entry.name))
    
    executor = concurrent.futures.ThreadPoolExecutor(max_workers = os.cpu_count())
    result = list(executor.map(count_number_of_files,subdir))
    for n,s in result:
        total_files = total_files + n
        total_size  = total_size + s
    
    end = time.time()
    
    print('total number of files:{}, total bytes:{}, execution time:{}'.format(total_files,total_size,end-begin))
    
def executor_submit(path):
	begin = time.time()
	total_files = 0
	total_size  = 0
	subdir = []
	for entry in os.scandir(path):
		if entry.is_file():
			total_files = total_files + 1
			total_size  = total_size + os.path.getsize(os.path.join(path,entry.name))
		elif entry.is_dir():
			subdir.append(os.path.join(path,entry.name))
    
	executor = concurrent.futures.ThreadPoolExecutor(max_workers = os.cpu_count())
    
	fs = [executor.submit(count_number_of_files,p) for p in subdir]
	for future in concurrent.futures.as_completed(fs):
		n,s = future.result()
		total_files = total_files + n
		total_size  = total_size + s
    
	end = time.time()

	print('total number of files:{}, total bytes:{}, execution time:{}'.format(total_files,total_size,end-begin))

if __name__=="__main__":
	path = 'g:\\'
	executor_submit(path)
	executor_map(path)
    
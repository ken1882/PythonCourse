# -*- coding: utf-8 -*-
"""
Created on Sat Oct 14 20:28:56 2017

@author: Admin
"""
import threading

x = 0
#def func(v):
#    global x
#    for i in range(1000000):
#        x = v
#        if x != v:
#            print('thread: {} v: {} x: {}'.format(threading.current_thread().name,v,x))



def func(v, lock):
    global x
    for i in range(1000000):
        lock.acquire()

        x = v
        if x != v:
            print('thread: {} v: {} x: {}'.format(threading.current_thread().name,v,x))

        lock.release()

lock = threading.Lock()
t1 = threading.Thread(target=func,args=(1,lock))
t2 = threading.Thread(target=func,args=(2,lock))

t1.start()
t2.start()

t1.join()
t2.join()




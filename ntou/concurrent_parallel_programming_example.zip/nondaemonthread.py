# -*- coding: utf-8 -*-
"""
Created on Sun Dec 24 16:57:17 2017

@author: Admin
"""

import threading
import time

def thread_func():
    while True:
        time.sleep(1)
    

thread_list = [threading.Thread(target=thread_func,daemon=False) for _ in range(100)]
for a_thread in thread_list:
    a_thread.start()

print('main thread is going to exit')